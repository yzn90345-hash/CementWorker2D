package com.example.cementworker;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(new GameView(this)); }

    static class GameView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float px=180, py=520; int level=1, xp=0, money=0;
        boolean carrying=false, finished=false; long last=0; Random rnd=new Random();
        RectF bag=new RectF(820,470,900,550), truck=new RectF(1030,420,1240,570);
        GameView(Context c){super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true);}
        void txt(Canvas c,String s,float x,float y,float size){p.setTextSize(size);p.setColor(Color.WHITE);c.drawText(s,x,y,p);}
        protected void onDraw(Canvas c){
            int w=getWidth(),h=getHeight();
            p.setColor(Color.rgb(125,190,235)); c.drawRect(0,0,w,h,p);
            p.setColor(Color.rgb(82,82,82)); c.drawRect(0,h-180,w,h,p);
            p.setColor(Color.rgb(175,175,175)); c.drawRect(520,130,980,h-180,p);
            p.setColor(Color.DKGRAY); c.drawRect(570,70,930,130,p);
            p.setColor(Color.LTGRAY); c.drawRect(610,185,890,230,p);
            // smokestack
            p.setColor(Color.DKGRAY); c.drawRect(860,20,920,130,p);
            p.setColor(Color.GRAY); c.drawCircle(890,15,22,p);
            // truck
            p.setColor(Color.rgb(40,90,150)); c.drawRect(truck,p);
            p.setColor(Color.BLACK); c.drawCircle(1070,575,28,p); c.drawCircle(1190,575,28,p);
            // bag
            p.setColor(Color.rgb(235,235,220)); c.drawRect(bag,p);
            txt(c,"إسمنت",830,515,16);
            // player
            p.setColor(Color.rgb(30,30,30)); c.drawCircle(px,py-45,25,p);
            p.setColor(Color.rgb(230,140,60)); c.drawRect(px-25,py-20,px+25,py+55,p);
            p.setColor(Color.DKGRAY); c.drawRect(px-25,py+55,px-5,py+105,p); c.drawRect(px+5,py+55,px+25,py+105,p);
            if(carrying){p.setColor(Color.WHITE);c.drawRect(px-20,py-5,px+20,py+35,p);txt(c,"كيس",px-16,py+23,12);}
            // HUD
            p.setColor(Color.argb(210,0,0,0)); c.drawRoundRect(new RectF(15,15,430,120),18,18,p);
            txt(c,"عامل الإسمنت",30,45,25); txt(c,"المستوى: "+level+"   XP: "+xp+"/100",30,75,19); txt(c,"المال: $"+money,30,102,18);
            // controls
            p.setColor(Color.argb(190,30,30,30));
            c.drawCircle(90,h-85,55,p); c.drawCircle(220,h-85,55,p); c.drawCircle(350,h-85,55,p);
            txt(c,"←",68,h-70,38); txt(c,"↑",200,h-70,38); txt(c,"→",328,h-70,38);
            p.setColor(Color.argb(190,20,110,60)); c.drawRoundRect(new RectF(w-220,h-145,w-25,h-45),20,20,p);
            txt(c,carrying?"تسليم":"حمل",w-165,h-82,25);
            if(finished){
                p.setColor(Color.argb(235,0,0,0));c.drawRect(0,0,w,h,p);
                txt(c,"🎉 مبروك!",w/2-130,h/2-40,45);
                txt(c,"أصبحت مدير معمل الإسمنت",w/2-250,h/2+15,30);
                txt(c,"النهاية",w/2-55,h/2+60,25);
            } else {
                txt(c, carrying?"أوصل الكيس إلى الشاحنة":"اذهب إلى كيس الإسمنت واحمله",650,115,22);
            }
        }
        public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN && e.getAction()!=MotionEvent.ACTION_UP) return true;
            if(e.getAction()==MotionEvent.ACTION_UP){
                float x=e.getX(),y=e.getY(); int h=getHeight(),w=getWidth();
                if(finished) return true;
                if(y>h-160){
                    if(x<150) px-=55; else if(x<285) py-=55; else if(x<430) px+=55;
                    invalidate(); return true;
                }
                if(x>w-240 && y>h-170){
                    if(!carrying && Math.abs(px-bag.centerX())<120){carrying=true;}
                    else if(carrying && Math.abs(px-truck.centerX())<180){
                        carrying=false; xp+=25; money+=50;
                        if(xp>=100){xp=0; level++; if(level>=10){level=10; finished=true;}}
                    }
                    invalidate();
                }
            }
            return true;
        }
    }
}
